from mahsulot import Mahsulot
from machine import Machine

lib = Machine()

kitob1 = Mahsulot("Aloe", "10000")
kitob2 = Mahsulot("Coco Cola", "7000")

print(lib.add(kitob1))
print(lib.getprice(kitob1))
print(lib.add( kitob2))

