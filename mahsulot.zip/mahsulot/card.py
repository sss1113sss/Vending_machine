class Card:

    def __init__(self,id: int, pul: float) -> None:
        self._id = id
        self._pul = pul

    @property
    def id(self):
        return self.id

    @property
    def pul(self):
        return self._pul

    def to_string(self):
        return self._id + ": " + self._pul

    def __eq__(self, __o: object) -> bool:
        return self.id == __o.id and self.pul == __o.pul