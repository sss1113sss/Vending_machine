from mahsulot import Mahsulot
from card import Card
class Machine:

    def __init__(self) -> None:
       
        self.mahsulot_list: list[Mahsulot] = []
        self.card_list: list[Card] = []
        self.card_pul:int[Card.pul]
        self.card_id:int[Card.id]
   

    def add(self, mahsulot: Mahsulot):
        self.mahsulot_list.append(Mahsulot)
        return "mahsulot qo'shildi"
    def add(self, card: Card):
        self.card_list.append(Card)
        return "mahsulot qo'shildi"
    def rechard(self, card_pul: Card.pul,card_id:Card.id):
        if(Card.id==card_id):
            self.card_pul=Card.pul
            return "pul qo'shildi"
        else:
            return   Card.__init__()
    

    def getprice(self, mahsulot: Mahsulot):
        for in_mahsulot in self.mahsulot_list:
            if in_mahsulot == mahsulot:
                return Mahsulot.narxi
        return -1.0
    
    
    def getcard(self, card: Card):
        for in_card in self.card_list:
            if in_card == card:
                return Card.id and Card.pul
        return -1.0