class Mahsulot:

    def __init__(self, nomi: str, narxi: str) -> None:
        self._nomi = nomi
        self._narxi = narxi

    @property
    def nomi(self):
        return self._nomi

    @property
    def narxi(self):
        return self._narxi

    def to_string(self):
        return self._nomi + ": " + self._narxi

    def __eq__(self, __o: object) -> bool:
        return self.nomi == __o.nomi and self.narxi == __o.narxi